
//תרגילים

// א

// var number = 10;
// while (number <= 19) {
//     console.log(number);
//     number++;   
// }

// for (i = 10; i<=19; i++) 
//     {console.log(i); }  


// ב

// var number = 10;
// while (number <= 40) {
//     if(number % 2 === 0)
//     {
//         console.log(number);
//     }
//     number++;   
// }

// for (i = 10; i<=40; i++) {
//     if(i % 2 == 0)
// {console.log(i);}
// }


// ג

// var number = 300;
// while (number <= 333) {
//     if(number % 2 === 1)
//     {
//         console.log(number);
//     }
//     number++;   
// }

// for (i = 300; i<=333; i++) {
//     if(i % 2 == 1)
// {console.log(i);}
// }


// ד

// var number = 5;
// while (number <= 50) {
//     if(number % 5 === 3)
//     {
//         console.log(number);
//     }
//     number++;   
// }

// for (i = 5; i<=50; i++) {
//     if(i % 5 == 3)
// {console.log(i);}
// }

// אתגר

function getAnswer(x)
{
    if(x !== parseInt(x)) {return 'numbers only'}
    
    var number = [];
     var prime = [];

for (i =2; i <= x; ++i)
{
   if(!number [i]) 
   {
       prime.push(i);
       for (j = i << 1; j <= x; j += i)
        {
       number[j] = true;      
       }
   }
}
return prime;
}


function thereYet(y)
{
    if (y === 'yes' || y === 'yeah')  // if input is yes or yeah alert yayy
    {
    alert('yayy'); 
    }
    else //if not return 'are we there yet ?' until input is yes/yeah
    { 
        while(true)
        {
        var j =   prompt('are we there yet ?');  

         if (j === "yes" ||j === 'yeah')
         {
             alert('yayy');
             break;
         }  
         
        }   
    }
}

function binGap(num){
    if(num !== parseInt(num)) {return 'numbers only'}
  
    const binNum = num.toString(2); // toString(2) converts the number to binary format, when used on a number return the binary equivalent of the numeric value.
  
    const array = binNum.split('1').map((binGap, index, binArr) => { // split the binary string we obtained using 1 creating an array of empty strings.iterate through the array with .map() and subject each item to a condition.
         return binArr[index + 1] != undefined ? binGap.length : 0; //return length of empty string or zeros if the value at the next index (index + 1) within the array is not undefined .if the value of the next index is undefined return 0.
     });   
    return Math.max.apply(Math, array); // return the number of the longest binary gap as if user input was 1040 to longest binary gap in 1040 is 5, so return 5.
  }